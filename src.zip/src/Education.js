function Education() {
    return(
        <div className="education">
            <h3>Education:</h3>
            <ul id="eduList">
                <li>SkillSpire</li>
                <li>Bellevue College</li>
                <li>Auburn High School</li>
            </ul>
        </div>
    )
}
export default Education;