function Contact() {
    return(
        <div className="contact">
            <h3>Contact Me:</h3>
            <p>Email: justin@showcasemi.com</p>
            <p>Phone: (425) 555-5555</p>
        </div>
    );
}
export default Contact;