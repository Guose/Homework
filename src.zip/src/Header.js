function Header() {
    return(
        <div className="header">
            <h3>Header:</h3>
            <p>Experienced and dedicated C# software developer and election data processor with proven troubleshooting, leadership, and communication skills.</p>
        </div>
    );
}
export default Header;