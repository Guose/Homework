function Objectives() {
    return (
        <div className="obj">
            <h3>Objectives:</h3>
            <ul id="objList">
                <li>Learn how to proficiently use React</li>
                <li>Develop Web Applications</li>
                <li>Use everything I learned at Skillspire</li>
                <li>Get a better paying gig!</li>
            </ul>
        </div>
    );
}

export default Objectives;