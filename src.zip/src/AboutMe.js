function AboutMe() {
    return (
        <div className="about">
            <h3>More About Me</h3>
            <ul id="aboutList">
                <li>I play and write my own music</li>
                <li>Learn quickly</li>
                <li>High attention to detail</li>
            </ul>
        </div>
    );
}
export default AboutMe;